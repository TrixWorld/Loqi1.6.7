﻿
namespace Loqi_X
{
    partial class loqisploit
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(loqisploit));
            this.Loqi = new FlatUI.FormSkin();
            this.flatTabControl1 = new FlatUI.FlatTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.flatTabControl2 = new FlatUI.FlatTabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.flatClose1 = new FlatUI.FlatClose();
            this.flatMini1 = new FlatUI.FlatMini();
            this.fastColoredTextBox1 = new FastColoredTextBoxNS.FastColoredTextBox();
            this.flatButton1 = new FlatUI.FlatButton();
            this.flatButton2 = new FlatUI.FlatButton();
            this.flatButton3 = new FlatUI.FlatButton();
            this.flatButton4 = new FlatUI.FlatButton();
            this.flatButton5 = new FlatUI.FlatButton();
            this.flatButton6 = new FlatUI.FlatButton();
            this.flatButton7 = new FlatUI.FlatButton();
            this.flatLabel1 = new FlatUI.FlatLabel();
            this.flatLabel2 = new FlatUI.FlatLabel();
            this.flatTextBox1 = new FlatUI.FlatTextBox();
            this.flatButton8 = new FlatUI.FlatButton();
            this.flatButton9 = new FlatUI.FlatButton();
            this.flatButton10 = new FlatUI.FlatButton();
            this.flatButton11 = new FlatUI.FlatButton();
            this.flatButton12 = new FlatUI.FlatButton();
            this.flatButton13 = new FlatUI.FlatButton();
            this.flatButton14 = new FlatUI.FlatButton();
            this.Loqi.SuspendLayout();
            this.flatTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.flatTabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fastColoredTextBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Loqi
            // 
            this.Loqi.BackColor = System.Drawing.Color.White;
            this.Loqi.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Loqi.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Loqi.Controls.Add(this.flatMini1);
            this.Loqi.Controls.Add(this.flatClose1);
            this.Loqi.Controls.Add(this.flatTabControl1);
            this.Loqi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Loqi.FlatColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Loqi.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Loqi.HeaderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Loqi.HeaderMaximize = false;
            this.Loqi.Location = new System.Drawing.Point(0, 0);
            this.Loqi.Name = "Loqi";
            this.Loqi.Size = new System.Drawing.Size(597, 322);
            this.Loqi.TabIndex = 0;
            this.Loqi.Text = "Loqi X";
            // 
            // flatTabControl1
            // 
            this.flatTabControl1.ActiveColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatTabControl1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatTabControl1.Controls.Add(this.tabPage1);
            this.flatTabControl1.Controls.Add(this.tabPage2);
            this.flatTabControl1.Controls.Add(this.tabPage3);
            this.flatTabControl1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatTabControl1.ItemSize = new System.Drawing.Size(120, 40);
            this.flatTabControl1.Location = new System.Drawing.Point(3, 12);
            this.flatTabControl1.Name = "flatTabControl1";
            this.flatTabControl1.SelectedIndex = 0;
            this.flatTabControl1.Size = new System.Drawing.Size(594, 310);
            this.flatTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.flatTabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.tabPage1.BackgroundImage = global::Loqi_X.Properties.Resources.photo_1497250681960_ef046c08a56e;
            this.tabPage1.Controls.Add(this.flatButton3);
            this.tabPage1.Controls.Add(this.flatButton2);
            this.tabPage1.Controls.Add(this.flatButton1);
            this.tabPage1.Controls.Add(this.fastColoredTextBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(586, 262);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Main";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.tabPage2.BackgroundImage = global::Loqi_X.Properties.Resources.photo_1497250681960_ef046c08a56e;
            this.tabPage2.Controls.Add(this.flatTextBox1);
            this.tabPage2.Controls.Add(this.flatLabel2);
            this.tabPage2.Controls.Add(this.flatLabel1);
            this.tabPage2.Controls.Add(this.flatButton6);
            this.tabPage2.Controls.Add(this.flatButton5);
            this.tabPage2.Controls.Add(this.flatButton4);
            this.tabPage2.Location = new System.Drawing.Point(4, 44);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(586, 262);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Scripts";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.tabPage3.Controls.Add(this.flatTabControl2);
            this.tabPage3.Location = new System.Drawing.Point(4, 44);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(586, 262);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Games";
            // 
            // flatTabControl2
            // 
            this.flatTabControl2.ActiveColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatTabControl2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatTabControl2.Controls.Add(this.tabPage4);
            this.flatTabControl2.Controls.Add(this.tabPage5);
            this.flatTabControl2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.flatTabControl2.ItemSize = new System.Drawing.Size(120, 40);
            this.flatTabControl2.Location = new System.Drawing.Point(0, 0);
            this.flatTabControl2.Name = "flatTabControl2";
            this.flatTabControl2.SelectedIndex = 0;
            this.flatTabControl2.Size = new System.Drawing.Size(587, 266);
            this.flatTabControl2.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.flatTabControl2.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.tabPage4.BackgroundImage = global::Loqi_X.Properties.Resources.photo_1497250681960_ef046c08a56e;
            this.tabPage4.Controls.Add(this.flatButton14);
            this.tabPage4.Controls.Add(this.flatButton13);
            this.tabPage4.Controls.Add(this.flatButton12);
            this.tabPage4.Controls.Add(this.flatButton11);
            this.tabPage4.Controls.Add(this.flatButton10);
            this.tabPage4.Controls.Add(this.flatButton9);
            this.tabPage4.Controls.Add(this.flatButton8);
            this.tabPage4.Controls.Add(this.flatButton7);
            this.tabPage4.Location = new System.Drawing.Point(4, 44);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(579, 218);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Games";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.tabPage5.BackgroundImage = global::Loqi_X.Properties.Resources.photo_1497250681960_ef046c08a56e;
            this.tabPage5.Location = new System.Drawing.Point(4, 44);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(579, 218);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "Games2";
            // 
            // flatClose1
            // 
            this.flatClose1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.flatClose1.BackColor = System.Drawing.Color.White;
            this.flatClose1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.flatClose1.Font = new System.Drawing.Font("Marlett", 10F);
            this.flatClose1.Location = new System.Drawing.Point(578, 0);
            this.flatClose1.Name = "flatClose1";
            this.flatClose1.Size = new System.Drawing.Size(18, 18);
            this.flatClose1.TabIndex = 1;
            this.flatClose1.Text = "flatClose1";
            this.flatClose1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // flatMini1
            // 
            this.flatMini1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.flatMini1.BackColor = System.Drawing.Color.White;
            this.flatMini1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(47)))), ((int)(((byte)(49)))));
            this.flatMini1.Font = new System.Drawing.Font("Marlett", 12F);
            this.flatMini1.Location = new System.Drawing.Point(554, -1);
            this.flatMini1.Name = "flatMini1";
            this.flatMini1.Size = new System.Drawing.Size(18, 18);
            this.flatMini1.TabIndex = 2;
            this.flatMini1.Text = "flatMini1";
            this.flatMini1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // fastColoredTextBox1
            // 
            this.fastColoredTextBox1.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.fastColoredTextBox1.AutoScrollMinSize = new System.Drawing.Size(401, 36);
            this.fastColoredTextBox1.BackBrush = null;
            this.fastColoredTextBox1.BackgroundImage = global::Loqi_X.Properties.Resources.photo_1497250681960_ef046c08a56e;
            this.fastColoredTextBox1.CharHeight = 18;
            this.fastColoredTextBox1.CharWidth = 10;
            this.fastColoredTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.fastColoredTextBox1.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.fastColoredTextBox1.Font = new System.Drawing.Font("Courier New", 12F);
            this.fastColoredTextBox1.ForeColor = System.Drawing.Color.Red;
            this.fastColoredTextBox1.IsReplaceMode = false;
            this.fastColoredTextBox1.Location = new System.Drawing.Point(4, 6);
            this.fastColoredTextBox1.Name = "fastColoredTextBox1";
            this.fastColoredTextBox1.Paddings = new System.Windows.Forms.Padding(0);
            this.fastColoredTextBox1.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.fastColoredTextBox1.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("fastColoredTextBox1.ServiceColors")));
            this.fastColoredTextBox1.Size = new System.Drawing.Size(583, 186);
            this.fastColoredTextBox1.TabIndex = 0;
            this.fastColoredTextBox1.Text = "Warn(\'Loqi X - best Rovlox exploit!\')\r\n";
            this.fastColoredTextBox1.Zoom = 100;
            // 
            // flatButton1
            // 
            this.flatButton1.BackColor = System.Drawing.Color.Transparent;
            this.flatButton1.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton1.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton1.Location = new System.Drawing.Point(3, 194);
            this.flatButton1.Name = "flatButton1";
            this.flatButton1.Rounded = false;
            this.flatButton1.Size = new System.Drawing.Size(106, 32);
            this.flatButton1.TabIndex = 1;
            this.flatButton1.Text = "Execute";
            this.flatButton1.TextColor = System.Drawing.Color.Yellow;
            this.flatButton1.Click += new System.EventHandler(this.flatButton1_Click);
            // 
            // flatButton2
            // 
            this.flatButton2.BackColor = System.Drawing.Color.Transparent;
            this.flatButton2.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton2.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton2.Location = new System.Drawing.Point(126, 194);
            this.flatButton2.Name = "flatButton2";
            this.flatButton2.Rounded = false;
            this.flatButton2.Size = new System.Drawing.Size(106, 32);
            this.flatButton2.TabIndex = 2;
            this.flatButton2.Text = "Clear";
            this.flatButton2.TextColor = System.Drawing.Color.Yellow;
            this.flatButton2.Click += new System.EventHandler(this.flatButton2_Click);
            // 
            // flatButton3
            // 
            this.flatButton3.BackColor = System.Drawing.Color.Transparent;
            this.flatButton3.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton3.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton3.Location = new System.Drawing.Point(472, 194);
            this.flatButton3.Name = "flatButton3";
            this.flatButton3.Rounded = false;
            this.flatButton3.Size = new System.Drawing.Size(106, 32);
            this.flatButton3.TabIndex = 3;
            this.flatButton3.Text = "Inject";
            this.flatButton3.TextColor = System.Drawing.Color.Yellow;
            this.flatButton3.Click += new System.EventHandler(this.flatButton3_Click);
            // 
            // flatButton4
            // 
            this.flatButton4.BackColor = System.Drawing.Color.Transparent;
            this.flatButton4.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton4.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton4.Location = new System.Drawing.Point(15, 6);
            this.flatButton4.Name = "flatButton4";
            this.flatButton4.Rounded = false;
            this.flatButton4.Size = new System.Drawing.Size(106, 32);
            this.flatButton4.TabIndex = 3;
            this.flatButton4.Text = "Btools";
            this.flatButton4.TextColor = System.Drawing.Color.Yellow;
            this.flatButton4.Click += new System.EventHandler(this.flatButton4_Click);
            // 
            // flatButton5
            // 
            this.flatButton5.BackColor = System.Drawing.Color.Transparent;
            this.flatButton5.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton5.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton5.Location = new System.Drawing.Point(15, 68);
            this.flatButton5.Name = "flatButton5";
            this.flatButton5.Rounded = false;
            this.flatButton5.Size = new System.Drawing.Size(106, 32);
            this.flatButton5.TabIndex = 4;
            this.flatButton5.Text = "Walkspeed";
            this.flatButton5.TextColor = System.Drawing.Color.Yellow;
            this.flatButton5.Click += new System.EventHandler(this.flatButton5_Click);
            // 
            // flatButton6
            // 
            this.flatButton6.BackColor = System.Drawing.Color.Transparent;
            this.flatButton6.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton6.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton6.Location = new System.Drawing.Point(15, 118);
            this.flatButton6.Name = "flatButton6";
            this.flatButton6.Rounded = false;
            this.flatButton6.Size = new System.Drawing.Size(106, 32);
            this.flatButton6.TabIndex = 5;
            this.flatButton6.Text = "ClickTP";
            this.flatButton6.TextColor = System.Drawing.Color.Yellow;
            this.flatButton6.Click += new System.EventHandler(this.flatButton6_Click);
            // 
            // flatButton7
            // 
            this.flatButton7.BackColor = System.Drawing.Color.Transparent;
            this.flatButton7.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton7.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton7.Location = new System.Drawing.Point(19, 16);
            this.flatButton7.Name = "flatButton7";
            this.flatButton7.Rounded = false;
            this.flatButton7.Size = new System.Drawing.Size(113, 71);
            this.flatButton7.TabIndex = 3;
            this.flatButton7.Text = "Jailbreak";
            this.flatButton7.TextColor = System.Drawing.Color.Yellow;
            this.flatButton7.Click += new System.EventHandler(this.flatButton7_Click);
            // 
            // flatLabel1
            // 
            this.flatLabel1.AutoSize = true;
            this.flatLabel1.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel1.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel1.ForeColor = System.Drawing.Color.White;
            this.flatLabel1.Location = new System.Drawing.Point(450, 25);
            this.flatLabel1.Name = "flatLabel1";
            this.flatLabel1.Size = new System.Drawing.Size(0, 13);
            this.flatLabel1.TabIndex = 6;
            this.flatLabel1.Click += new System.EventHandler(this.flatLabel1_Click);
            // 
            // flatLabel2
            // 
            this.flatLabel2.AutoSize = true;
            this.flatLabel2.BackColor = System.Drawing.Color.Transparent;
            this.flatLabel2.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.flatLabel2.ForeColor = System.Drawing.Color.White;
            this.flatLabel2.Location = new System.Drawing.Point(361, 60);
            this.flatLabel2.Name = "flatLabel2";
            this.flatLabel2.Size = new System.Drawing.Size(0, 13);
            this.flatLabel2.TabIndex = 7;
            this.flatLabel2.Click += new System.EventHandler(this.flatLabel2_Click);
            // 
            // flatTextBox1
            // 
            this.flatTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.flatTextBox1.FocusOnHover = false;
            this.flatTextBox1.Location = new System.Drawing.Point(97, -202);
            this.flatTextBox1.MaxLength = 32767;
            this.flatTextBox1.Multiline = false;
            this.flatTextBox1.Name = "flatTextBox1";
            this.flatTextBox1.ReadOnly = false;
            this.flatTextBox1.Size = new System.Drawing.Size(75, 29);
            this.flatTextBox1.TabIndex = 8;
            this.flatTextBox1.Text = "flatTextBox1";
            this.flatTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.flatTextBox1.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.flatTextBox1.UseSystemPasswordChar = false;
            this.flatTextBox1.TextChanged += new System.EventHandler(this.flatTextBox1_TextChanged);
            // 
            // flatButton8
            // 
            this.flatButton8.BackColor = System.Drawing.Color.Transparent;
            this.flatButton8.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton8.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton8.Location = new System.Drawing.Point(19, 125);
            this.flatButton8.Name = "flatButton8";
            this.flatButton8.Rounded = false;
            this.flatButton8.Size = new System.Drawing.Size(113, 71);
            this.flatButton8.TabIndex = 4;
            this.flatButton8.Text = "Mad City";
            this.flatButton8.TextColor = System.Drawing.Color.Yellow;
            this.flatButton8.Click += new System.EventHandler(this.flatButton8_Click);
            // 
            // flatButton9
            // 
            this.flatButton9.BackColor = System.Drawing.Color.Transparent;
            this.flatButton9.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton9.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton9.Location = new System.Drawing.Point(166, 16);
            this.flatButton9.Name = "flatButton9";
            this.flatButton9.Rounded = false;
            this.flatButton9.Size = new System.Drawing.Size(113, 71);
            this.flatButton9.TabIndex = 5;
            this.flatButton9.Text = "Arsenal";
            this.flatButton9.TextColor = System.Drawing.Color.Yellow;
            this.flatButton9.Click += new System.EventHandler(this.flatButton9_Click);
            // 
            // flatButton10
            // 
            this.flatButton10.BackColor = System.Drawing.Color.Transparent;
            this.flatButton10.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton10.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton10.Location = new System.Drawing.Point(166, 125);
            this.flatButton10.Name = "flatButton10";
            this.flatButton10.Rounded = false;
            this.flatButton10.Size = new System.Drawing.Size(113, 71);
            this.flatButton10.TabIndex = 6;
            this.flatButton10.Text = "Break point";
            this.flatButton10.TextColor = System.Drawing.Color.Yellow;
            this.flatButton10.Click += new System.EventHandler(this.flatButton10_Click);
            // 
            // flatButton11
            // 
            this.flatButton11.BackColor = System.Drawing.Color.Transparent;
            this.flatButton11.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton11.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton11.Location = new System.Drawing.Point(306, 16);
            this.flatButton11.Name = "flatButton11";
            this.flatButton11.Rounded = false;
            this.flatButton11.Size = new System.Drawing.Size(113, 71);
            this.flatButton11.TabIndex = 7;
            this.flatButton11.Text = "Lumber tycoon 2";
            this.flatButton11.TextColor = System.Drawing.Color.Yellow;
            this.flatButton11.Click += new System.EventHandler(this.flatButton11_Click);
            // 
            // flatButton12
            // 
            this.flatButton12.BackColor = System.Drawing.Color.Transparent;
            this.flatButton12.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton12.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton12.Location = new System.Drawing.Point(306, 125);
            this.flatButton12.Name = "flatButton12";
            this.flatButton12.Rounded = false;
            this.flatButton12.Size = new System.Drawing.Size(113, 71);
            this.flatButton12.TabIndex = 8;
            this.flatButton12.Text = "MM2";
            this.flatButton12.TextColor = System.Drawing.Color.Yellow;
            this.flatButton12.Click += new System.EventHandler(this.flatButton12_Click);
            // 
            // flatButton13
            // 
            this.flatButton13.BackColor = System.Drawing.Color.Transparent;
            this.flatButton13.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton13.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton13.Location = new System.Drawing.Point(448, 16);
            this.flatButton13.Name = "flatButton13";
            this.flatButton13.Rounded = false;
            this.flatButton13.Size = new System.Drawing.Size(113, 71);
            this.flatButton13.TabIndex = 9;
            this.flatButton13.Text = "Strong man simulator";
            this.flatButton13.TextColor = System.Drawing.Color.Yellow;
            this.flatButton13.Click += new System.EventHandler(this.flatButton13_Click);
            // 
            // flatButton14
            // 
            this.flatButton14.BackColor = System.Drawing.Color.Transparent;
            this.flatButton14.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.flatButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flatButton14.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flatButton14.Location = new System.Drawing.Point(448, 125);
            this.flatButton14.Name = "flatButton14";
            this.flatButton14.Rounded = false;
            this.flatButton14.Size = new System.Drawing.Size(113, 71);
            this.flatButton14.TabIndex = 10;
            this.flatButton14.Text = "Darkhub";
            this.flatButton14.TextColor = System.Drawing.Color.Yellow;
            this.flatButton14.Click += new System.EventHandler(this.flatButton14_Click);
            // 
            // loqisploit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 322);
            this.Controls.Add(this.Loqi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "loqisploit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Loqi X";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.Loqi.ResumeLayout(false);
            this.flatTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.flatTabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.fastColoredTextBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private FlatUI.FormSkin Loqi;
        private FlatUI.FlatTabControl flatTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private FlatUI.FlatTabControl flatTabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private FlatUI.FlatMini flatMini1;
        private FlatUI.FlatClose flatClose1;
        private FlatUI.FlatButton flatButton3;
        private FlatUI.FlatButton flatButton2;
        private FlatUI.FlatButton flatButton1;
        private FastColoredTextBoxNS.FastColoredTextBox fastColoredTextBox1;
        private FlatUI.FlatTextBox flatTextBox1;
        private FlatUI.FlatLabel flatLabel2;
        private FlatUI.FlatLabel flatLabel1;
        private FlatUI.FlatButton flatButton6;
        private FlatUI.FlatButton flatButton5;
        private FlatUI.FlatButton flatButton4;
        private FlatUI.FlatButton flatButton7;
        private FlatUI.FlatButton flatButton14;
        private FlatUI.FlatButton flatButton13;
        private FlatUI.FlatButton flatButton12;
        private FlatUI.FlatButton flatButton11;
        private FlatUI.FlatButton flatButton10;
        private FlatUI.FlatButton flatButton9;
        private FlatUI.FlatButton flatButton8;
    }
}

